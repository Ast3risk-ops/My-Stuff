print("I can multiply")
Name = input("What is your name >")
print("Hello", Name)
print("Time to multiply the area of a rectangle")
num1 = int(input("what is the length in cm > "))
num2 = int(input("What is the width in cm > "))
SUM = num1 * num2
print("The rectangle's area is", SUM, "cm2")