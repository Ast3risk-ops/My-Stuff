# A calculator in Python but Mario themed
print("If you ran this program by double click, it won't work")
print("Please only run this in mu or the Python IDLE")
print("Hello, it's a me Mario!!!!!!!!!!!!!! I am a calculator now!!!!")
welcome = ("Well, welcome")
name = input(" Now, what is your name?>")
print(welcome, name)
print("Now, what will we be adding today?")
num1 = int(input("What is the first number that we are going to add?"))
num2 = int(input("What is the second number that we will be adding?"))
SUM = num1 + num2
print(" It appears that the sum of", num1, "+", num2, "is equal to", SUM)