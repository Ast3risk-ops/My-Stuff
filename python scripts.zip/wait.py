# How to use the time module to make a wait command

# Import the time module like this:
import time
# Type in time.sleep and, in brackets, the number of seconds to wait
# EX:
time.sleep(1)
# You can put this in between any 2 commands
# EX:
print("Hi")
time.sleep(2)
print("There")