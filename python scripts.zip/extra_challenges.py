aList = [100, 200, 300, 400, 500]
aList.reverse()
print(aList)
list1 = ["M", "na", "i", "Ke"]
list2 = ["y", "me", "s", "lly"]
list3 = [list1[0] + list2[0], list1[1] + list2[1], list1[2] + list2[2], list1[3] + list2[3]]
print(list3)
list20 = [5, 10, 20, 25, 50, 20]
del list20[2]
list20.insert(2, 200)
print(list20)
list21 = [5, 20, 15, 20, 25, 50, 20]
del list21[1]
del list21[3]
del list21[2]
del list21[3]
print(list21)
listname = ["Mike", "",  "Emma", "Kelly", "", "Brad"]
del listname[1]
del listname[3]
print(listname)