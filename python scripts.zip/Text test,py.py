import time
print("Hi")
time.sleep(10)
sys.exit(["SUCCESS"])