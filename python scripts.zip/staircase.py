from random import randint
list = []
for item in range(27):
    list.append(randint(0,100))
    print(list)
print(list)