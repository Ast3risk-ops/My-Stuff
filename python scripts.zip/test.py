import time
print("If you want to see a secret message go to, https://www.mediafire.com/file/mibv6jfb3ltjdp5/Message_from_Jude_Middleton.txt/file")
print("If you want to see a secret message go to, https://www.mediafire.com/file/mibv6jfb3ltjdp5/Message_from_Jude_Middleton.txt/file")
print("You can also go to https://1drv.ms/t/s!ArudfbOpJsF_x0zDPwubmtWpb1Of?e=mhtEAl")
print("Or, https://swlsb-my.sharepoint.com/:t:/g/personal/0398313_swlauriersb_qc_ca/EatY-rltVztGg0jG7jXyUXABye3zuUPJ2hNdzqX8EaRg1w?e=Y5nErx")
print("If you are prompted, the password is Python")
print("It's ctrl+shift+C to copy as ctrl+C terminates the program")
time.sleep(300000)