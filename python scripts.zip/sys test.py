from sys import exit
print("Hi")
exit(["ERR_BUTT_JIM"])