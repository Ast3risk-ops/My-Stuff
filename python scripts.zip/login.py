# Login prompt
name = input("username > ")
if name == "spacedude609":
    print("Hello, creator")
elif name == "BL4Z3":
    print("Hello friend")
elif name == "Ian":
    print("Hello, friend")
elif name == "butt jim":
    print("Nobody likes you,", name)
elif name == "bl4z3":
    print("hello, friend")
elif name == "ian":
    print("Hello, friend")
else:
    print("Get out of here", name, "Shutting down")