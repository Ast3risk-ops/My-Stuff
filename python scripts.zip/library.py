# Learning about libraries
from time import sleep
from random import randint
from sys import exit
randtime = randint(1,10)
print("Hi")
sleep(randtime)
print("There")
print("I was asleep for,", randtime, "seconds")