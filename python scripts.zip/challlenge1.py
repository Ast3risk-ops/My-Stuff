welcome = ("Welcome")
print("Hello, I am Mario, your personal calculator")
name = input("What is your name?>")
message = welcome + name
print(message)
print("Let's add some numbers!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
print("adding time")
number1 = int(input("Number 1>"))
number2 = int(input("Number 2>"))
SUM = number1 + number2
print("The rsult of", number1, "+", number2, "is", SUM)